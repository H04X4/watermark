<?php
// URL вашего Flask-приложения
$baseUrl = 'http://94.247.210.28:5558';  // Замените на свой URL, если он отличается

// Функция для загрузки изображения
function uploadImage($imagePath, $baseUrl) {
    $url = $baseUrl . '/upload_manual';
    $file = new CURLFile($imagePath, 'image/png', basename($imagePath));
    $postData = array('image' => $file);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);

    if ($httpCode == 200) {
        echo "Изображение $imagePath успешно загружено\n";
    } else {
        echo "Ошибка загрузки изображения $imagePath: $response\n";
    }
}

// Функция для обработки изображений в папке draw
function processImages($baseUrl) {
    $url = $baseUrl . '/process_manual';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);

    if ($httpCode == 200) {
        echo "Обработка изображений успешно завершена\n";
    } else {
        echo "Ошибка обработки изображений: $response\n";
    }
}

// Функция для получения обработанного изображения
function downloadProcessedImage($filename, $baseUrl, $outputDir) {
    $url = $baseUrl . '/get_processed_image/' . urlencode($filename);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);

    if ($httpCode == 200) {
        $data = json_decode($response, true);
        if (isset($data['image'])) {
            $imgData = base64_decode($data['image']);
            $outputPath = $outputDir . DIRECTORY_SEPARATOR . $filename;
            file_put_contents($outputPath, $imgData);
            echo "Обработанное изображение $filename успешно загружено\n";
        } else {
            echo "Ошибка: обработанное изображение не найдено в ответе\n";
        }
    } else {
        echo "Ошибка получения обработанного изображения: $response\n";
    }
}

// Главная часть скрипта
$inputDir = 'maskphoto';
$outputDir = 'downloaded_images';

// Проверка на существование директорий
if (!is_dir($inputDir)) {
    echo "Директория $inputDir не существует.\n";
    exit(1);
}

if (!is_dir($outputDir)) {
    mkdir($outputDir, 0777, true);
}

// Получение списка PNG файлов
$pngFiles = array_filter(scandir($inputDir), function($file) {
    return pathinfo($file, PATHINFO_EXTENSION) === 'png';
});

// Проверка на наличие PNG файлов
if (empty($pngFiles)) {
    echo "В директории $inputDir нет файлов с расширением .png.\n";
    exit(1);
}

// Загружаем каждое изображение
foreach ($pngFiles as $pngFile) {
    $imagePath = $inputDir . DIRECTORY_SEPARATOR . $pngFile;
    uploadImage($imagePath, $baseUrl);
}

// После загрузки всех изображений выполняем их обработку
processImages($baseUrl);

// После обработки всех изображений загружаем их
foreach ($pngFiles as $pngFile) {
    downloadProcessedImage($pngFile, $baseUrl, $outputDir);
}
?>
