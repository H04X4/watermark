<?php
// URL API
$uploadUrl = 'http://94.247.210.28:5556/upload_automatic';
$processUrl = 'http://94.247.210.28:5556/process_automatic';
$getProcessedImageUrl = 'http://94.247.210.28:5556/get_processed_image';

// Путь к папке с изображениями
$imageFolder = 'mainphoto';
$downloadFolder = 'downloaded_images';

// Создание папки для сохранения загруженных изображений, если она не существует
if (!file_exists($downloadFolder)) {
    mkdir($downloadFolder, 0777, true);
}

// Получение списка файлов .png из папки
$imagePaths = glob($imageFolder . '/*.png');

// Функция для загрузки изображений на сервер
function uploadImage($imagePath, $uploadUrl) {
    $file = new CURLFile($imagePath, 'image/png', basename($imagePath));
    $postData = array('image' => $file);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $uploadUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    curl_close($ch);
    
    return [$httpCode, $response];
}

// Загрузка изображений на сервер
foreach ($imagePaths as $imagePath) {
    if (file_exists($imagePath)) {
        list($httpCode, $response) = uploadImage($imagePath, $uploadUrl);
        if ($httpCode == 200) {
            echo "Изображение $imagePath успешно загружено на сервер\n";
        } else {
            echo "Ошибка загрузки изображения $imagePath: $httpCode\n";
        }
    } else {
        echo "Файл $imagePath не найден\n";
    }
}

// Запуск обработки изображений
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $processUrl);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if ($httpCode == 200) {
    $data = json_decode($response, true);
    if (isset($data['processed_images'])) {
        foreach ($data['processed_images'] as $imageData) {
            $filename = $imageData['filename'];

            // Сохранение обработанных изображений
            $rotatedImagePath = $downloadFolder . '/' . 'rotated_' . $filename;
            $maskImagePath = $downloadFolder . '/' . 'mask_' . $filename;

            file_put_contents($rotatedImagePath, base64_decode($imageData['rotated_image']));
            file_put_contents($maskImagePath, base64_decode($imageData['mask_image']));

            echo "Изображение {$filename} успешно обработано и сохранено\n";
        }
    } else {
        echo "Обработанные изображения не найдены в ответе сервера\n";
    }
} else {
    echo "Ошибка при запуске обработки: $httpCode\n";
}

curl_close($ch);

// Функция для получения обработанных изображений из папки result
function getProcessedImage($filename, $getProcessedImageUrl, $downloadFolder) {
    $url = $getProcessedImageUrl . '/' . $filename;
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    curl_close($ch);
    
    if ($httpCode == 200) {
        $data = json_decode($response, true);
        if (isset($data['image'])) {
            $imageData = base64_decode($data['image']);
            $filePath = $downloadFolder . '/' . $filename;
            file_put_contents($filePath, $imageData);
            echo "Изображение {$filename} успешно сохранено в {$filePath}\n";
        } else {
            echo "Ошибка: Изображение не найдено в ответе сервера\n";
        }
    } else {
        echo "Ошибка при запросе изображения: $httpCode\n";
    }
}

// Получение и сохранение изображений из папки result
foreach ($imagePaths as $imagePath) {
    $filename = basename($imagePath);
    getProcessedImage($filename, $getProcessedImageUrl, $downloadFolder);
}
?>
